package br.edu.fatecfranca.exe01;
public final class Aluno {
    private int nrAluno, idade;
    private float p1, p2, notaFinal;
    private String nome;
    
    public Aluno(){ }
    
    public Aluno(int nrAluno, int idade, float p1, float p2, String nome){
        this.setNrAluno(nrAluno);
        this.setIdadeAluno(idade);
        this.setP1(p1);
        this.setP2(p2);
        this.setNomeAluno(nome);
        
    }
    public void setNrAluno(int nrAluno){
        if (String.valueOf(nrAluno).length() == 6){
            this.nrAluno = nrAluno;
        }
        else{
            System.out.println("Número do Aluno inválido!!");
            this.nrAluno = 0;
        }
    }
    public void setNomeAluno(String nome){
        if (nome.length() <= 30){
            this.nome = nome;
        }
        else{
            System.out.println("Nome do Aluno inválido!!");
            this.nome = "Inválido!!";
        }
    }
    public void setIdadeAluno(int idade){
        if  (idade > 0) {
            this.idade = idade;
        }
        else{
            System.out.println("Idade do Aluno inválida!!");
            this.idade = 0;
        }
    }

    public void setP1(float p1) {
    if (this.p1 >= 0 && this.p1 < 10){
        this.p1 = p1;
    }
    else {
        System.out.println("Nota inválida!!");
        this.p1 = 0;
    }
}

    public void setP2(float p2) {
      if (this.p2 >= 0 && this.p2 < 10){
        this.p2 = p2;
      }
      else{
        this.p2 = 0;
      }
    }
      public void notaFinal(){
        this.notaFinal = (this.p1 + this.p2) / 2;
        
    }

    public int getNrAluno() {
        return nrAluno;
    }

    public int getIdade() {
        return idade;
    }

    public float getP1() {
        return p1;
    }

    public float getP2() {
        return p2;
    }

    public String getNome() {
        return nome;
    }
    
 
    
    public void mostra(){
        System.out.println("Número do Aluno: " + this.nrAluno + "\n" +
                            "Idade do Aluno: " + this.idade + "\n" + 
                            "Nome do Aluno: " + this.nome + " \n " + 
                            "P1: " + this.p1 + "\n" + "P2: " + this.p2 +
                            "\n " + "Nota Final: " + this.notaFinal);
    }
}
