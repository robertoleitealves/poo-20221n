package br.edu.fatecfranca.exe01;
public class TestaAluno {

    public static void main(String[] args) {
        // TODO code application logic here
        // public Aluno(int nrAluno, int idade, float p1, float p2, String nome)
        Aluno obj1 = new Aluno (123456, 15, 5, 6, "Roberto");
            obj1.notaFinal();
            obj1.mostra();
            
    }
    
}
