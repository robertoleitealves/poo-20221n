
package br.edu.fatecfranca.exe01;


/**
 *
 * @author rober
 */
public final class Cliente {
    private String nrConta;
    private String nrAgencia;
    private String nome;
    float saldo;
    
    
public Cliente(){
    
}
public Cliente(String nrConta, String nrAgencia, String nome, float saldo){
    this.setNroConta(nrConta);
    this.setNroAgencia(nrAgencia);
    this.setNome(nome);
    this.setSaldo(saldo);
}

public void setNroConta(String nrConta){
    if ((nrConta.length() == 8) && (nrConta.charAt(6) == '-')) {
        this.nrConta = nrConta;
    } 
    else {
        System.out.println("Número de Conta invalido!!");
        this.nrConta = "inválido";
    }
}
    public void setNroAgencia(String nrAgencia){
    if ((nrConta.length() == 6) && (nrConta.charAt(4) == '-')) {
        this.nrAgencia = nrAgencia;
    } 
    else {
        System.out.println("Número de Agência invalido!!");
        this.nrAgencia = "inválido";        
    }
 }  
    public void setNome (String nome){
        if (nome.length() <= 30){
            this.nome = nome;
        }
        else {
            System.out.println("Nome inválido");
                this.nome = "inválido";
        }
    }
    
    public void setSaldo(float saldo){
        if (saldo >= 0){
            this.saldo = saldo;
        }
        else {
            System.out.println("Saldo inválido!!");
        }
    }
    
    public void sacar(float x){
        this.setSaldo(this.saldo - x);
    }
     public void depositar(float x){
        this.setSaldo(this.saldo + x);
    }
     
     //getters
     
     public String getNroConta(){
         return this.nrConta;
     }
     public String getNroAgencia(){
         return this.nrAgencia;
     }
     public String getNome(){
         return this.nome;
     }
     
     public float getSaldo(){
         return this.saldo;
     }
     
     public void mostra(){
         System.out.println("Conta: " + this.nrConta + "\n" +
                            "Agência: " + this.nrAgencia + "\n" + 
                            "Nome: " + this.nome + " \n " + 
                            "Saldo: " + this.saldo);
     }
    
}
