/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.fatecfranca.exe01;

/**
 *
 * @author rober
 */
public class Teste {
   
   
    public static void main(String[] args) {
         Niver obj = new Niver();
         obj.setDia(3);
         obj.setDia(80);
         obj.setDia(-3);
         obj.setMes("Janeiro");
         obj.setMes ("Outono");
         
//         System.out.println("Dia: " + obj.dia + "\n" +
                         //   "Mês: " + obj.mes );
         
         
         
         Niver obj2 = new Niver (7, "Janeiro");
         Niver obj3 = new Niver (38, "Verão");
         
    }
    
}
